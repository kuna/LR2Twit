﻿LR2Twit
by kuna - http://kuna.wo.tc
Twitter - @kuna_KR
Released - 10.05.20

☆ Release note
alpha ver - 5/18
 - first release
 - Autotwit Supported
 - options supported

alpha ver2 - 5/19
 - blocked duplicated running using mutex
 - and few fixes...

ver 1.0 - 5/20
 - few regex supported
 - more stabled
 - supports more exact infos and datas and etc...

☆ 사용법 -
1. Twitter ID/PASS를 쓰고 Auth를 하여 토큰을 받습니다.
2. 옵션을 적절히 설정합니다. 끝 (...)

☆ 팁 - 
1. 레겍스(치환자)를 이용하여 여러 언어, 혹은 다양한 방식으로 트윗 메시지를 설정할 수 있습니다.
settings.ini를 편집해 보세요.
ex)
TWIT_MESSAGE="[TITLE]" [SUBTITLE] 곡을 [GUAGE] 게이지로 [RESULT]하였습니다[AUTO]. EX SCORE : [EXS]/[EXMS] - [RATE]%([RANK]) - [PG]/[GR]/[GD]/[BD]/[PR] #BMS #LR2
TWIT_MESSAGE=I [RESULT]ed "[TITLE]" [SUBTITLE] song[AUTO]. EX SCORE : [EXS]/[EXMS] - [RATE]%([RANK]) - [PG]/[GR]/[GD]/[BD]/[PR] #BMS #LR2
TWIT_MESSAGE="[TITLE]" [SUBTITLE] 曲を　[GUAGE]のゲージで　[RESULT]しました[AUTO]。EX SCORE : [EXS]/[EXMS] - [RATE]%([RANK]) - [PG]/[GR]/[GD]/[BD]/[PR] #BMS #LR2

2. 타 국가권들을 위해서 다양한 인코딩을 지원하도록 신경 썼습니다.
기본 인코딩은 CP949(EUC-KR)이며, 일본의 경우에는 SHIFT_JIS로 옵션을 바꾸면 어플로케일 없이도 쉽게 프로그램 사용이 가능합니다.
ex)
TWIT_ENCODING=CP949
TWIT_ENCODING=SHIFT_JIS

3. 현재까지 지원하는 레겍스들은 다음과 같습니다.
[SCORE]
[PG]
[GR]
[GD]
[BD]
[PR]
[EXS] - EX Score
[EXHS] - EX High Score
[EXMS] - EX MAX Score
[NC] - Note count
[MC] - Max combo
[TITLE] - title of song
[SUBTITLE] - subtitle (ex:7keys another / remixed by celas ....)
[ARTIST] - artist of song
[GENRE] - genre of song
[DIFF] - ☆00
[AUTO] - not writes anything but (AUTO-SCR) on setting auto scr
[IRTOT] - Internet Ranking total users
[IRNOW] - my max Internet Ranking

4. 건의사항은 @kuna_KR에 mention 해 주세요!



☆ Future plan
 - supporting ruv-it!, Trilogy
 - DirectX Overlay
 - auto Picting and uploading result scr to yfrog
 - custom judgement system for LR2